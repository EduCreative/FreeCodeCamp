# 25 + 5 Clock (FreeCodeCamp)

A Pen created on CodePen.io. Original URL: [https://codepen.io/EduCreative/pen/RwMEWxV](https://codepen.io/EduCreative/pen/RwMEWxV).

